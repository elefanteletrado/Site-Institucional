<?php
/**
* Plugin Name: Elefante Letrado - Pacote de Arquivos
* Description: Pacote de Arquivos
* Version: 1.0
* Author: CWI Software - Luiz Felipe Bertoldi de Oliveira
* Author URI: http://www.cwi.com.br
*/