-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: elsitedb-7-38.cfjabj2ewavb.sa-east-1.rds.amazonaws.com    Database: WPelefante
-- ------------------------------------------------------
-- Server version	5.6.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'nickname','Elefante Letrado'),(2,1,'first_name',''),(3,1,'last_name',''),(4,1,'description',''),(5,1,'rich_editing','true'),(6,1,'comment_shortcuts','false'),(7,1,'admin_color','fresh'),(8,1,'use_ssl','0'),(9,1,'show_admin_bar_front','true'),(10,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),(11,1,'wp_user_level','10'),(12,1,'dismissed_wp_pointers','wp360_locks,wp390_widgets,wp410_dfw,vc_pointers_backend_editor'),(13,1,'default_password_nag',''),(14,1,'show_welcome_panel','0'),(16,1,'wp_dashboard_quick_press_last_post_id','3587'),(17,1,'wp_user-settings','libraryContent=browse&editor=tinymce&imgsize=full&hidetb=1&mfold=o&posts_list_mode=list&wplink=1&advImgDetails=show&align=none&post_dfw=off&urlbutton=none'),(18,1,'wp_user-settings-time','1452865968'),(19,1,'nav_menu_recently_edited','58'),(20,1,'managenav-menuscolumnshidden','a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}'),(21,1,'metaboxhidden_nav-menus','a:12:{i:0;s:30:\"woocommerce_endpoints_nav_link\";i:1;s:8:\"add-post\";i:2;s:14:\"add-our-staffs\";i:3;s:11:\"add-product\";i:4;s:17:\"add-cupid_gallery\";i:5;s:17:\"add-cupid_classes\";i:6;s:19:\"add-cupid_countdown\";i:7;s:12:\"add-post_tag\";i:8;s:15:\"add-post_format\";i:9;s:20:\"add-classes_category\";i:10;s:15:\"add-product_cat\";i:11;s:15:\"add-product_tag\";}'),(22,1,'closedpostboxes_page','a:0:{}'),(23,1,'metaboxhidden_page','a:3:{i:0;s:10:\"postcustom\";i:1;s:7:\"slugdiv\";i:2;s:9:\"authordiv\";}'),(24,1,'billing_first_name',''),(25,1,'billing_last_name',''),(26,1,'billing_company',''),(27,1,'billing_address_1',''),(28,1,'billing_address_2',''),(29,1,'billing_city',''),(30,1,'billing_postcode',''),(31,1,'billing_country',''),(32,1,'billing_state',''),(33,1,'billing_phone',''),(34,1,'billing_email',''),(35,1,'shipping_first_name',''),(36,1,'shipping_last_name',''),(37,1,'shipping_company',''),(38,1,'shipping_address_1',''),(39,1,'shipping_address_2',''),(40,1,'shipping_city',''),(41,1,'shipping_postcode',''),(42,1,'shipping_country',''),(43,1,'shipping_state',''),(44,1,'closedpostboxes_cupid_gallery','a:0:{}'),(45,1,'metaboxhidden_cupid_gallery','a:1:{i:0;s:7:\"slugdiv\";}'),(46,1,'meta-box-order_cupid_classes','a:3:{s:4:\"side\";s:42:\"submitdiv,classes_categorydiv,postimagediv\";s:6:\"normal\";s:134:\"cupid_classes_qa_settings_metabox,cupid-meta-box-format-classes,postexcerpt,commentstatusdiv,commentsdiv,slugdiv,mymetabox_revslider_0\";s:8:\"advanced\";s:0:\"\";}'),(47,1,'screen_layout_cupid_classes','2'),(48,1,'closedpostboxes_cupid_classes','a:0:{}'),(49,1,'metaboxhidden_cupid_classes','a:1:{i:0;s:7:\"slugdiv\";}'),(50,1,'wpseo_ignore_tour','1'),(52,1,'wpseo_dismissed_conflicts','a:1:{s:10:\"open_graph\";a:1:{i:0;s:21:\"facebook/facebook.php\";}}'),(53,1,'wpseo_dismissed_gsc_notice','1'),(55,1,'wpseo_seen_about_version','3.1'),(56,1,'closedpostboxes_post','a:0:{}'),(57,1,'metaboxhidden_post','a:9:{i:0;s:33:\"g5plus-meta-box-post-format-image\";i:1;s:35:\"g5plus-meta-box-post-format-gallery\";i:2;s:33:\"g5plus-meta-box-post-format-video\";i:3;s:33:\"g5plus-meta-box-post-format-audio\";i:4;s:11:\"postexcerpt\";i:5;s:13:\"trackbacksdiv\";i:6;s:16:\"commentstatusdiv\";i:7;s:7:\"slugdiv\";i:8;s:9:\"authordiv\";}'),(58,1,'tgmpa_dismissed_notice_cupid','1'),(59,1,'_yoast_wpseo_profile_updated','1450874168'),(60,1,'wpseo_title',''),(61,1,'wpseo_metadesc',''),(62,1,'wpseo_metakey',''),(63,1,'wpseo_excludeauthorsitemap',''),(64,1,'googleplus',''),(65,1,'twitter',''),(66,1,'facebook',''),(90,1,'example_ignore_notice','true'),(94,1,'session_tokens','a:2:{s:64:\"d8de47503f2c643bf52b8ab03c327b01d5ccf939dac03a80313a14132263b64c\";a:4:{s:10:\"expiration\";i:1460997634;s:2:\"ip\";s:13:\"201.86.238.45\";s:2:\"ua\";s:109:\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36\";s:5:\"login\";i:1459788034;}s:64:\"ec1947c0591f1e5c0f5f90bc3e3b238a88e210b11964e02cfe87f3d3fb124e0a\";a:4:{s:10:\"expiration\";i:1461175507;s:2:\"ip\";s:13:\"201.86.238.45\";s:2:\"ua\";s:109:\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36\";s:5:\"login\";i:1459965907;}}'),(95,1,'closedpostboxes_dashboard','a:1:{i:0;s:17:\"dashboard_primary\";}'),(96,1,'metaboxhidden_dashboard','a:0:{}'),(97,1,'geoip_detect_dismissed_notices','a:2:{i:0;s:0:\"\";i:1;s:13:\"hostinfo_used\";}');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-06 18:29:48
