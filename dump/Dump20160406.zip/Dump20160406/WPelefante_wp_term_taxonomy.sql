-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: elsitedb-7-38.cfjabj2ewavb.sa-east-1.rds.amazonaws.com    Database: WPelefante
-- ------------------------------------------------------
-- Server version	5.6.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (1,1,'category','',0,1),(2,2,'product_type','',0,14),(3,3,'product_type','',0,0),(4,4,'product_type','',0,2),(5,5,'product_type','',0,0),(6,6,'category','Aprenda com o Sr. Elefante dicas super legais!',0,20),(8,8,'post_tag','',0,0),(9,9,'post_tag','',0,1),(10,10,'post_tag','',0,0),(11,11,'post_tag','',0,0),(12,12,'post_tag','',0,0),(13,13,'post_tag','',0,1),(14,14,'post_tag','',0,0),(15,15,'post_tag','',0,0),(16,16,'post_tag','',0,1),(17,17,'post_tag','',0,0),(18,18,'post_tag','',0,0),(19,19,'post_tag','',0,0),(20,20,'post_tag','',0,0),(21,21,'post_tag','',0,1),(22,22,'post_tag','',0,1),(23,23,'post_tag','',0,0),(24,24,'post_tag','',0,0),(25,25,'post_tag','',0,0),(28,28,'nav_menu','',0,13),(32,32,'product_cat','',0,13),(33,33,'product_cat','',0,11),(34,34,'product_cat','',0,12),(35,35,'product_cat','',0,13),(36,36,'product_cat','',0,12),(37,37,'product_tag','',0,1),(38,38,'product_tag','',0,1),(39,39,'product_cat','',0,12),(40,40,'product_cat','',0,8),(41,41,'product_tag','',0,1),(42,42,'product_tag','',0,2),(43,43,'product_tag','',0,1),(44,44,'product_tag','',0,1),(45,45,'post_format','',0,2),(46,46,'post_format','',0,1),(47,47,'post_format','',0,4),(48,48,'post_format','',0,1),(49,49,'product_tag','',0,1),(50,50,'product_tag','',0,1),(51,51,'product_tag','',0,1),(52,52,'product_tag','',0,1),(53,53,'category','Tudo o que tem saído sobre o Elefante Letrado na imprensa!',0,8),(54,54,'post_format','',0,0),(55,55,'post_tag','',0,1),(56,56,'post_tag','',0,1),(57,57,'post_tag','',0,3),(58,58,'nav_menu','',0,8),(59,59,'post_tag','',0,1),(60,60,'post_tag','',0,1),(61,61,'post_tag','',0,1),(62,62,'post_tag','',0,1),(63,63,'post_tag','',0,1),(67,67,'nav_menu','',0,4),(68,68,'category','',0,5),(69,69,'category','',0,12),(70,70,'category','',0,10),(71,71,'post_tag','',0,1),(72,72,'post_tag','',0,1),(73,73,'post_tag','',0,1),(74,74,'post_tag','',0,2),(75,75,'post_tag','',0,1),(76,76,'post_tag','',0,1),(77,77,'classes_category','Para crianças de 6 a 7 anos.',0,0),(78,78,'nav_menu','',0,2),(79,79,'category','',0,11),(80,80,'post_tag','',0,1),(81,81,'category','',0,2),(82,82,'category','',0,1),(83,83,'post_tag','',0,3),(84,84,'post_tag','',0,1),(85,85,'post_tag','',0,1),(86,86,'post_tag','',0,2),(87,87,'post_tag','',0,4),(88,88,'post_tag','',0,1),(89,89,'post_tag','',0,1),(90,90,'post_tag','',0,5),(91,91,'category','',0,4),(92,92,'post_tag','',0,1),(93,93,'post_tag','',0,1),(94,94,'post_tag','',0,1),(95,95,'post_tag','',0,3),(96,96,'post_tag','',0,1),(97,97,'post_tag','',0,1),(98,98,'post_tag','',0,2),(99,99,'post_tag','',0,1),(100,100,'post_tag','',0,1),(101,101,'post_tag','',0,1),(102,102,'post_tag','',0,1),(103,103,'post_tag','',0,1),(104,104,'post_tag','',0,2),(105,105,'post_tag','',0,1),(106,106,'post_tag','',0,1),(107,107,'post_tag','',0,1),(108,108,'post_tag','',0,0),(109,109,'post_tag','',0,0),(110,110,'post_tag','',0,0),(111,111,'post_tag','',0,0),(112,112,'post_tag','',0,0),(113,113,'post_tag','',0,0),(114,114,'post_tag','',0,0),(115,115,'post_tag','',0,0),(116,116,'post_tag','',0,1),(117,117,'post_tag','',0,1),(118,118,'post_tag','',0,2),(119,119,'post_tag','',0,1),(120,120,'post_tag','',0,1),(121,121,'post_tag','',0,1),(122,122,'post_tag','',0,1),(123,123,'post_tag','',0,1),(124,124,'post_tag','',0,1),(125,125,'post_tag','',0,1);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-06 18:30:02
