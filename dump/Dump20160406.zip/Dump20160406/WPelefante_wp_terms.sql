-- MySQL dump 10.13  Distrib 5.6.23, for Win64 (x86_64)
--
-- Host: elsitedb-7-38.cfjabj2ewavb.sa-east-1.rds.amazonaws.com    Database: WPelefante
-- ------------------------------------------------------
-- Server version	5.6.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (1,'Sem Categoria','sem-categoria',0),(2,'simple','simple',0),(3,'grouped','grouped',0),(4,'variable','variable',0),(5,'external','external',0),(6,'Dicas do Sr. Elefante','dicas-do-sr-elefante',0),(8,'activity room','activity-room',0),(9,'analytical skills','analytical-skills',0),(10,'audio','audio',0),(11,'childhood','childhood',0),(12,'dance room','dance-room',0),(13,'educational','educational',0),(14,'gallery','gallery',0),(15,'gallery post','gallery-post',0),(16,'image','image',0),(17,'kindergarten','kindergarten',0),(18,'mp3','mp3',0),(19,'multimedia','multimedia',0),(20,'music and art room','music-and-art-room',0),(21,'student','student',0),(22,'traffic park','traffic-park',0),(23,'video','video',0),(24,'vimeo','vimeo',0),(25,'youtube','youtube',0),(28,'Footer Menu','footer-menu',0),(32,'Outdoor Toys','outdoor-toys',0),(33,'Play Centres, Swings &amp; Slides','play-centres-swings-slides',0),(34,'Puzzles &amp; Learning','puzzles-learning',0),(35,'Wooden Playsets','wooden-playsets',0),(36,'Wooden Toys','wood-toys',0),(37,'Wooden Transporter','wooden-transporter',0),(38,'Wooden Truck','wooden-truck',0),(39,'Preschool Wooden Toys','preschool-wooden-toys',0),(40,'Garden &amp; Beach Games','garden-beach-games',0),(41,'outdoor toys','outdoor-toys',0),(42,'toys','toys',0),(43,'toy for boy','toy-for-boy',0),(44,'toy for girls','toy-for-girls',0),(45,'Image','post-format-image',0),(46,'Gallery','post-format-gallery',0),(47,'Video','post-format-video',0),(48,'Audio','post-format-audio',0),(49,'baby toy','baby-toy',0),(50,'toys for baby','toys-for-baby',0),(51,'toys for kid','toys-for-kid',0),(52,'Toys And Games','toys-and-games',0),(53,'Na Mídia','na-midia',0),(54,'post-format-link','post-format-link',0),(55,'tudo mais','tudo-mais',0),(56,'tv com','tv-com',0),(57,'scheila vontobel','scheila-vontobel',0),(58,'Elefante Letrado','elefante-letrado',0),(59,'Led Epstein','led-epstein',0),(60,'ilustração','ilustracao',0),(61,'programa network','programa-network',0),(62,'universo digital','universo-digital',0),(63,'band news','band-news',0),(67,'Footer - Menu - Elefante Letrado','footer-menu-elefante-letrado',0),(68,'Datas Comemorativas','datas-comemorativas',0),(69,'Livros infantis','livros-infantis',0),(70,'Elefante Letrado','elefante-letrado',0),(71,'tablet','tablet',0),(72,'jogos educativos','jogos-educativos',0),(73,'áudio sincronizado','audio-sincronizado',0),(74,'biblioteca virtual','biblioteca-virtual',0),(75,'biblioteca infantil','biblioteca-infantil',0),(76,'cantinho da leitura','cantinho-da-leitura',0),(77,'Nível F','nivel-f',0),(78,'Elefante Letrado - Esquerda','elefante-letrado-esquerda',0),(79,'Curiosidades','curiosidades',0),(80,'Curiosidades','curiosidades',0),(81,'DIY para crianças','diy-para-criancas',0),(82,'Para Colorir','para-colorir',0),(83,'leitura','leitura',0),(84,'diversão','diversao',0),(85,'ler é divertido','ler-e-divertido',0),(86,'pais e filhos','pais-e-filhos',0),(87,'Elefante Letrado','elefante-letrado',0),(88,'Hightlights','hightlights',0),(89,'inglês','ingles',0),(90,'crianças','criancas',0),(91,'Informação','informacao',0),(92,'Negócio Feminino','negocio-feminino',0),(93,'Entrevista','entrevista',0),(94,'férias','ferias',0),(95,'dicas','dicas',0),(96,'atividades','atividades',0),(97,'Volta às Aulas','volta-as-aulas',0),(98,'filhos','filhos',0),(99,'livros digitais','livros-digitais',0),(100,'famílias','familias',0),(101,'tecnologia','tecnologia',0),(102,'digital','digital',0),(103,'música','musica',0),(104,'criança','crianca',0),(105,'aprendizado','aprendizado',0),(106,'educação','educacao',0),(107,'benefícios','beneficios',0),(108,'gamificação','gamificacao',0),(109,'games','games',0),(110,'escola','escola',0),(111,'mundo digital','mundo-digital',0),(112,'interatividade','interatividade',0),(113,'internet','internet',0),(114,'locuções','locucoes',0),(115,'animações','animacoes',0),(116,'computador','computador',0),(117,'televisão','televisao',0),(118,'pais','pais',0),(119,'tecnologias','tecnologias',0),(120,'idade','idade',0),(121,'filho','filho',0),(122,'mídias digitais','midias-digitais',0),(123,'ambiente digital','ambiente-digital',0),(124,'clube do livro infantil','clube-do-livro-infantil',0),(125,'livros infantis','livros-infantis',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-06 18:30:05
